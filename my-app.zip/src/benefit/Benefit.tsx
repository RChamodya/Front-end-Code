
function Benefit(){
    return(
        <>

        </>
    )
}
export default Benefit;