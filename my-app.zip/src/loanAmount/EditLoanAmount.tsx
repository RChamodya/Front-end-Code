import {Typography} from "@mui/material";
import React from "react";

function EditLoanAmount(){


















    return(
        <>
            <Typography variant="h4"   mt={5}  textAlign="center">Edit Loan Amount</Typography>


        </>
    )
}
export default EditLoanAmount;