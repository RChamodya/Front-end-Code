function IdentifyCustomer(){

    return(
        <>

        </>
    )
}
export default IdentifyCustomer;