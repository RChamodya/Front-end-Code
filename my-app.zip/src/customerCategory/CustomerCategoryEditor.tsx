import React, {useEffect, useState} from "react";
import axios from "axios";

interface CustomerCategory {
    catId: number;
    catCode: string;
    categoryDescription: string;
    status: boolean;
    specializedCustomer: boolean;
    ageGreaterThan18: boolean;
    creditScore: number;
    income: number;
    isDeleted: boolean;
}

const CustomerCategoryEditor: React.FC = () => {
    const [customerCategory, setCustomerCategory] = useState<CustomerCategory | null>(null);

    useEffect(() => {

    }, []);

    async function updateCustomerCategory(customerCategory: CustomerCategory): Promise<void> {
        const { data } = await axios.put<void>(
            `http://localhost:8080/api/v1/category/update/${customerCategory.catId}`,
            customerCategory
        );
    }

    const handleEditClick = async () => {
        if (!customerCategory) {
            return;
        }

        await updateCustomerCategory(customerCategory);


    };

    return (
        <div>
            <h1>Customer Category Editor</h1>
            {customerCategory && (
                <form>
                    <input type="text" value={customerCategory.catCode} />
                    <input type="text" value={customerCategory.categoryDescription} />
                    <input type="checkbox" checked={customerCategory.status} />
                    <input type="checkbox" checked={customerCategory.specializedCustomer} />
                    <button type="button" onClick={handleEditClick}>
                        Edit
                    </button>
                </form>
            )}
        </div>
    );
};

export default CustomerCategoryEditor;
