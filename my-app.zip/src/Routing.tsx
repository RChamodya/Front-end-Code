import {Route, Router, Routes} from "react-router-dom";
import LandingPage from "./components/landingPage/LandingPage";
import CustomerCategory from "./customerCategory/CustomerCategory";
import Benefit from "./benefit/Benefit";
import IdentifyCustomer from "./identifyCustomer/Identify Customer";
import LoanAmount from "./loanAmount/LoanAmount";
import SubBenefit from "./subBenefit/SubBenefit";
import CustomerCategiryViewPage from "./customerCategory/CustomerCategiryViewPage";
import CustomerCategoryEditPage from "./customerCategory/CustomerCategoryEditPage";
import CategoryCreatePage from "./customerCategory/CategoryCreatePage";
import CreateLoanAmount from "./loanAmount/CreateLoanAmount";
import EditLoanAmount from "./loanAmount/EditLoanAmount";
import ViewLoanAmount from "./loanAmount/ViewLoanAmount";

function Routing(){

    return(
        <>

        <Routes>
          <Route path={"/"}  element={<LandingPage/>}/>
          <Route path={"/customerCategory"}  element={<CustomerCategory/>}/>
          <Route path={"/benefit"}  element={<Benefit/>}/>
          <Route path={"/identifyCustomer"}  element={<IdentifyCustomer/>}/>
          <Route path={"/loanAmount"}  element={<LoanAmount/>}/>
          <Route path={"/subBenefit"}  element={<SubBenefit/>}/>
          <Route path={"/viewCustomerCategory"}  element={<CustomerCategiryViewPage/>}/>
          <Route path={"/editCustomerCategory/*"}  element={<CustomerCategoryEditPage/>}/>
          <Route path={"/createCustomerCategory/*"}  element={<CategoryCreatePage/>}/>
          <Route path={"/createLoanAmount/*"}  element={<CreateLoanAmount/>}/>
          <Route path={"/editLoanAmount/*"}  element={<EditLoanAmount/>}/>
          <Route path={"/viewLoanAmount/*"}  element={<ViewLoanAmount/>}/>

        </Routes>



        </>
    )


}
export default Routing;