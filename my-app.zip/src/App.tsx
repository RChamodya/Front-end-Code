import React, {ReactNode} from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route} from 'react-router-dom';
import HomePage from './components/HomePage';
import Test from "./Test";
import CustomerCategory from "./customerCategory/CustomerCategory";
import CustomerCategoryEditor from "./customerCategory/CustomerCategoryEditor";
import LandingPage from "./components/landingPage/LandingPage";
import Routing from "./Routing";


function App() {
  return (
<>
    <Routing/>
</>
  );
}

export default App;
