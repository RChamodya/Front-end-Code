import {Button} from "@mui/material";

function BackButton() {
    return(
        <>

            <Button variant="contained">Contained</Button>
        </>
    )
}export default BackButton;